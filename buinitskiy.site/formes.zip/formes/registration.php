<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Регистрация</title>
  <link rel="stylesheet" href="../css/reg.css">
</head>

<body>
    <?php
// Страница регистрации нового пользователя

// Соединямся с БД
$link=mysqli_connect("localhost", "id16231784_alex", "Sh077912448!", "id16231784_a");

if(isset($_POST['submit']))
{
    $err = [];

    // проверям логин
    if(!preg_match("/^[a-zA-Z0-9]+$/",$_POST['login']))
    {
        $err[] = "Логин может состоять только из букв английского алфавита и цифр";
    }

    if(strlen($_POST['login']) < 3 or strlen($_POST['login']) > 30)
    {
        $err[] = "Логин должен быть не меньше 3-х символов и не больше 30";
    }

    // проверяем, не сущестует ли пользователя с таким именем
    $query = mysqli_query($link, "SELECT user_id FROM users WHERE user_login='".mysqli_real_escape_string($link, $_POST['login'])."'");
    if(mysqli_num_rows($query) > 0)
    {
        $err[] = "Пользователь с таким логином уже существует в базе данных";
    }

    // Если нет ошибок, то добавляем в БД нового пользователя
    if(count($err) == 0)
    {

        $login = $_POST['login'];

        // Убераем лишние пробелы и делаем двойное хеширование
        $password = md5(md5(trim($_POST['password'])));

        mysqli_query($link,"INSERT INTO users SET user_login='".$login."', user_password='".$password."'");
        header("Location: https://alexni.ga/buinitskiy.site/formes/autorization.html"); exit();
    }
    else
    {
        print "<b>При регистрации произошли следующие ошибки:</b><br>";
        foreach($err AS $error)
        {
            print $error."<br>";
        }
    }
}
?>

  <div class="based">
    <div class="formabg">
      <div class="titletext">
        Регистрация
      </div>
      <form method="POST">
      <div class="forma">
        <input name="login" type="text" class="vvod" placeholder="Имя пользователя">
        <input name="password" type="password" class="vvod" placeholder="Пароль">
        <input type="text" class="vvod" placeholder="Повторите пароль">
        <textarea  placeholder="Информация о пользователе"></textarea>
        <div class="radio">
        <left><a>Ваш пол: </a></left>
        <input id="radiopol" type="radio" name="radio" value="Мужской" >
        <label for="radio-1">Мужской</label>
        <input id="radiopol" type="radio" name="radio" value="Женский" >
        <label for="radio-2">Женский</label>
        </div>
      </div>
      <input class="buttonvhod" name="submit" type="submit" value="Зарегистрироваться">
      <div class="obg">
        <div><a class="ssilka" href="../formes/index.php">
            Вход
          </a>
        <a class="ssilka" href="../index.php" >
          Главная
        </a></div>
      </div>
    </div>
  </div>
</body>

</html>